package com.example.reservation.ports.in;

public interface CancelReservationUseCase {
    void cancel(Long reservationId);
}

INSERT INTO vehicles (model, year, available, license_plate, price_per_day)
VALUES
  ('Toyota Corolla', 2021, true, '1234-ABC', 50.00),
  ('Ford Fiesta', 2020, true, '5678-DEF', 40.00),
  ('Renault Clio', 2022, false, '9012-GHI', 38.00),
  ('Volkswagen Golf', 2023, true, '3456-JKL', 55.00);

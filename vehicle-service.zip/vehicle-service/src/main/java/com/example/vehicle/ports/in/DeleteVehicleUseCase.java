package com.example.vehicle.ports.in;

public interface DeleteVehicleUseCase {
    void delete(Long id);
}

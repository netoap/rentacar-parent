package com.example.vehicle.ports.in;

public interface ReturnVehicleUseCase {
    void returnVehicle(Long vehicleId);
}
